create database myapp2;
use myapp2;
commit;

create table board(
	bno bigint primary key auto_increment,
	title varchar(100) not null,
    content varchar(1000) not null,
    writer varchar(50) not null,
    regdate datetime default now(),
    moddate datetime default now()
);
select * from board;