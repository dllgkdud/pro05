package com.company.myapp.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.company.myapp.domain.Board;

public interface BoardRepository extends JpaRepository<Board, Long>{

}
